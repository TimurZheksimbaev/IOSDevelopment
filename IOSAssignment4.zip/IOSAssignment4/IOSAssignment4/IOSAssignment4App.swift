//
//  IOSAssignment4App.swift
//  IOSAssignment4
//
//  Created by Тимур Жексимбаев on 30.06.2023.
//

import SwiftUI

@main
struct IOSAssignment4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
