//
//  IOSAssignment7App.swift
//  IOSAssignment7
//
//  Created by Тимур Жексимбаев on 12.07.2023.
//

import SwiftUI

@main
struct IOSAssignment7App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
