//
//  IOSAssignment5App.swift
//  IOSAssignment5
//
//  Created by Тимур Жексимбаев on 09.07.2023.
//

import SwiftUI

@main
struct IOSAssignment5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
