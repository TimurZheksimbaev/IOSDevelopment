//
//  CharacterModel.swift
//  IOSAssignment5
//
//  Created by Тимур Жексимбаев on 09.07.2023.
//

import Foundation

